// -*- C++ -*-
// Copyright (C) Dmitry Igrishin
// For conditions of distribution and use, see files LICENSE.txt or common.hpp

#define DMITIGR_COMMON_HEADER_ONLY
#define DMITIGR_COMMON_BUILDING
#include "dmitigr/common.hpp"
