// -*- C++ -*-
// Copyright (C) Dmitry Igrishin
// For conditions of distribution and use, see files LICENSE.txt or common.hpp

#ifdef DMITIGR_COMMON_NOMINMAX
#undef DMITIGR_COMMON_NOMINMAX
#undef NOMINMAX
#endif

#ifdef DMITIGR_COMMON_INLINE
#undef DMITIGR_COMMON_INLINE
#endif
