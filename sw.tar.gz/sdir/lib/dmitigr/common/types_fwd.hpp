// -*- C++ -*-
// Copyright (C) Dmitry Igrishin
// For conditions of distribution and use, see files LICENSE.txt or common.hpp

#ifndef DMITIGR_COMMON_TYPES_FWD_HPP
#define DMITIGR_COMMON_TYPES_FWD_HPP

/**
 * @brief Public API.
 *
 * @warning The nested namespaces `detail` contains implementation details
 * which should not be used in the client code.
 */
namespace dmitigr {

namespace io {
class Descriptor;
} // namespace io

namespace net {
enum class Communication_mode;

class iDescriptor;

class Endpoint_id;
class iEndpoint_id;

class Listener;
class iListener;

class Listener_options;
class iListener_options;
} // namespace net

/**
 * @brief The namespace dmitigr::detail contains an implementation details.
 */
namespace detail {
} // namespace detail

} // namespace dmitigr

#endif  // DMITIGR_COMMON_TYPES_FWD_HPP
