// -*- C++ -*-
// Copyright (C) Dmitry Igrishin
// For conditions of distribution and use, see files LICENSE.txt or common.hpp

#ifndef DMITIGR_COMMON_EXCEPTIONS_HPP
#define DMITIGR_COMMON_EXCEPTIONS_HPP

#include "dmitigr/common/dll.hpp"

#include <string>
#include <system_error>

namespace dmitigr {

/**
 * @brief Represents exceptions thrown on system error.
 */
class Sys_exception : public std::system_error {
public:
  /**
   * @brief The constructor.
   */
  explicit Sys_exception(const std::string& func);

  /**
   * @brief Prints the last system error to the standard error.
   */
  static void report(const char* const func) noexcept;

  /**
   * @returns The last system error code.
   */
  static int last_error() noexcept;
};

#ifdef _WIN32
/**
 * @brief Represents a category of Windows Socket Application (WSA) errors.
 */
class Wsa_error_category : public std::error_category {
public:
  /**
   * @returns The literal `dmitigr_wsa_error`.
   */
  const char* name() const noexcept override;

  /**
   * @returns The string that describes the error condition denoted by `ev`.
   *
   * @remarks The caller should not rely on the return value as it a subject to change.
   */
  std::string message(int ev) const override;
};

/**
 * @returns The reference to instance of type Wsa_error_category.
 */
DMITIGR_COMMON_API const Wsa_error_category& wsa_error_category() noexcept;

/**
 * @brief Represents exceptions thrown on WSA error.
 */
class Wsa_exception : public std::system_error {
public:
  /**
   * @brief The constructor.
   */
  explicit Wsa_exception(const std::string& func);

  /**
   * @brief Prints the last WSA error to the standard error.
   */
  static void report(const char* const func) noexcept;

  /**
   * @returns The last WSA error code.
   */
  static int last_error() noexcept;
};
#endif

#ifdef _WIN32
#define DMITIGR_NET_EXCEPTION_BASE Wsa_exception
#else
#define DMITIGR_NET_EXCEPTION_BASE Sys_exception
#endif

class Net_exception : public DMITIGR_NET_EXCEPTION_BASE {
public:
  using DMITIGR_NET_EXCEPTION_BASE::DMITIGR_NET_EXCEPTION_BASE;
  using DMITIGR_NET_EXCEPTION_BASE::report;
  using DMITIGR_NET_EXCEPTION_BASE::last_error;
};

} // namespace dmitigr

#ifdef DMITIGR_COMMON_HEADER_ONLY
#include "dmitigr/common/exceptions.cpp"
#endif

#endif  // DMITIGR_COMMON_EXCEPTIONS_HPP
