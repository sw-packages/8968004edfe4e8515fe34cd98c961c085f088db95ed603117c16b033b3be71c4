// -*- C++ -*-
// Copyright (C) Dmitry Igrishin
// For conditions of distribution and use, see files LICENSE.txt or common.hpp

#ifndef DMITIGR_COMMON_GRAPHICSMAGICK_HPP
#define DMITIGR_COMMON_GRAPHICSMAGICK_HPP

#include "dmitigr/common/dll.hpp"

#include <iosfwd>

namespace dmitigr::img::graphicsmagick {

enum class File_type { gif = 1, jpeg, png };

/**
 * @brief GraphicsMagick initialization.
 */
DMITIGR_COMMON_API void init(const char* app_path);

/**
 * @returns MIME in the GraphicsMagick notation.
 */
DMITIGR_COMMON_API const char* file_type_c_str(File_type file_type);

/**
 * @brief Resizes the image read from `input` and writes the result to `output`.
 */
DMITIGR_COMMON_API void resize(std::istream& input,
  std::ostream& output,
  unsigned int output_x,
  unsigned int output_y,
  File_type output_type,
  unsigned int output_quality = 90);

} // namespace dmitigr::img::graphicsmagick

#ifdef DMITIGR_COMMON_HEADER_ONLY
#include "dmitigr/common/graphicsmagick.cpp"
#endif

#endif  // DMITIGR_COMMON_GRAPHICSMAGICK_HPP
