// -*- C++ -*-
// Copyright (C) Dmitry Igrishin
// For conditions of distribution and use, see files LICENSE.txt or common.hpp

#ifndef _WIN32
#error windows.hpp is usable only on Microsoft Windows!
#endif

#ifndef DMITIGR_COMMON_WINDOWS_HPP
#define DMITIGR_COMMON_WINDOWS_HPP

#include "dmitigr/common/exceptions.hpp"
#include "dmitigr/common/implementation_header.hpp"

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <Windows.h>

namespace dmitigr::os::windows {

/**
 * @internal
 *
 * @brief A very thin wrapper around HANDLE data type.
 */
struct Handle_guard final {
  ~Handle_guard()
  {
    if (!close())
      Sys_exception::report("CloseHandle");
  }

  explicit Handle_guard(HANDLE handle = INVALID_HANDLE_VALUE) noexcept
    : handle_{handle}
  {}

  // Non-copyable.
  Handle_guard(const Handle_guard&) = delete;
  Handle_guard& operator=(const Handle_guard&) = delete;

  Handle_guard(Handle_guard&& rhs) noexcept
    : handle_{rhs.handle_}
  {
    rhs.handle_ = INVALID_HANDLE_VALUE;
  }

  Handle_guard& operator=(Handle_guard&& rhs) noexcept
  {
    if (this != &rhs) {
      Handle_guard tmp{std::move(rhs)};
      swap(tmp);
    }
    return *this;
  }

  void swap(Handle_guard& other) noexcept
  {
    std::swap(handle_, other.handle_);
  }

  operator HANDLE() noexcept
  {
    return handle_;
  }

  operator const HANDLE() const noexcept
  {
    return handle_;
  }

  /**
   * @returns `true` on success, or `false` otherwise.
   */
  bool close() noexcept
  {
    bool result{true};
    if (handle_ != INVALID_HANDLE_VALUE) {
      result = ::CloseHandle(handle_);
      if (result)
        handle_ = INVALID_HANDLE_VALUE;
    }
    return result;
  }

private:
  HANDLE handle_{INVALID_HANDLE_VALUE};
};

} // namespace dmitigr::os::windows

#endif  // DMITIGR_COMMON_WINDOWS_HPP
