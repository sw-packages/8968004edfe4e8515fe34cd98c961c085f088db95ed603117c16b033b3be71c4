// -*- C++ -*-
// Copyright (C) Dmitry Igrishin
// For conditions of distribution and use, see files LICENSE.txt or common.hpp

#ifndef DMITIGR_COMMON_MACROS_HPP
#define DMITIGR_COMMON_MACROS_HPP

#define DMITIGR_STRINGIZED(s) #s
#define DMITIGR_XSTRINGIZED(s) DMITIGR_STRINGIZED(s)

#endif // DMITIGR_COMMON_MACROS_HPP
