// -*- C++ -*-
// Copyright (C) Dmitry Igrishin
// For conditions of distribution and use, see files LICENSE.txt or common.hpp

#ifndef DMITIGR_COMMON_CONFIG_HPP
#define DMITIGR_COMMON_CONFIG_HPP

#include "dmitigr/common/dll.hpp"
#include "dmitigr/common/filesystem.hpp"

#include <map>
#include <optional>
#include <string>
#include <utility>

namespace dmitigr::config {

/**
 * @brief Class Flat represents a flat configuration store.
 */
class Flat {
public:
  DMITIGR_COMMON_API explicit Flat(const std::filesystem::path& path);

  DMITIGR_COMMON_API const std::optional<std::string>& string_parameter(const std::string& name) const;

  DMITIGR_COMMON_API std::optional<bool> boolean_parameter(const std::string& name) const;

  DMITIGR_COMMON_API const std::map<std::string, std::optional<std::string>>& parameters() const;

private:
  /**
   * @returns Parsed config entry. The format of `line` can be:
   *   - "param=one";
   *   - "param='one two  three';
   *   - "param='one \'two three\' four'.
   */
  std::pair<std::string, std::string> parsed_config_entry(const std::string& line);

  /**
   * @returns Parsed config file. The format of `line` can be:
   *   - "param=one";
   *   - "param='one two  three';
   *   - "param='one \'two three\' four'.
   */
  std::map<std::string, std::optional<std::string>> parsed_config(const std::filesystem::path& path);

  bool is_invariant_ok() const;

  static const std::optional<std::string>& null_string_parameter();

  std::map<std::string, std::optional<std::string>> parameters_;
};

} // namespace dmitigr::config

#ifdef DMITIGR_COMMON_HEADER_ONLY
#include "dmitigr/common/config.cpp"
#endif

#endif  // DMITIGR_COMMON_CONFIG_HPP
