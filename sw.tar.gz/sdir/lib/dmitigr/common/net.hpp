// -*- C++ -*-
// Copyright (C) Dmitry Igrishin
// For conditions of distribution and use, see files LICENSE.txt or common.hpp

#ifndef DMITIGR_COMMON_NET_HPP
#define DMITIGR_COMMON_NET_HPP

#include "dmitigr/common/basics.hpp"
#include "dmitigr/common/dll.hpp"
#include "dmitigr/common/filesystem_experimental.hpp"
#include "dmitigr/common/types_fwd.hpp"

#include <chrono>
#include <memory>
#include <optional>
#include <string>

#ifdef _WIN32
#include <cstdint>
#endif

namespace dmitigr::net {

/**
 * @brief Represents a native type that masquerades a socket descriptor.
 */
#ifdef _WIN32
  #ifdef _WIN64
    using Socket_native = std::uint_fast64_t;
  #else
    using Socket_native = std::uint_fast32_t;
  #endif
#else
  using Socket_native = int;
#endif

/**
 * @brief Represents a communication mode.
 */
enum class Communication_mode {
#ifdef _WIN32
  /** Denotes that a Windows Named Pipe is used for communication. */
  wnp,
#else
  /** Denotes that a Unix Domain Socket is used for communication. */
  uds,
#endif
  /** Denotes that a network protocol is used for communication. */
  net
};

/**
 * @brief Represents a socket readiness.
 */
enum class Socket_readiness {
  /** Any I/O operation on a socket would block. */
  unready = 0,

  /** Read operation on a socket would not block. */
  read_ready = 2,

  /** Write operation on a socket would not block. */
  write_ready = 4,

  /** Exceptions are available. */
  exceptions = 8
};

DMITIGR_DECLARE_ENUM_BITMASK_OPERATORS(Socket_readiness)

/**
 * @brief Represents an Internet Protocol version.
 */
enum class Ip_version {
  /** The Internet Protocol version 4. */
  v4 = 4,

  /** The Internet Protocol version 6. */
  v6 = 6
};

// =============================================================================

/**
 * @brief A very thin RAII-wrapper around the Socket_native data type.
 */
struct Socket_guard final {
  ~Socket_guard();

  Socket_guard() noexcept;
  explicit Socket_guard(Socket_native socket) noexcept;

  // Non-copyable.
  Socket_guard(const Socket_guard&) = delete;
  Socket_guard& operator=(const Socket_guard&) = delete;

  // Movable.
  Socket_guard(Socket_guard&& rhs) noexcept;
  Socket_guard& operator=(Socket_guard&& rhs) noexcept;

  void swap(Socket_guard& other) noexcept;

  operator Socket_native() const noexcept;

  /**
   * @returns Zero on success, or non-zero otherwise.
   */
  int close() noexcept;

private:
  Socket_native socket_;
};

/**
 * @brief Represents an IP address.
 */
class Ip_address {
public:
  /**
   * @brief The destructor.
   */
  virtual ~Ip_address() = default;

  /**
   * @returns The new instance of type `Ip_address`.
   */
  static DMITIGR_COMMON_API std::unique_ptr<Ip_address> make(const std::string& str);

  /**
   * @returns `true` if `text` is either valid IPv4 or IPv6 address, or
   * `false` otherwise.
   */
  static DMITIGR_COMMON_API bool is_valid(const std::string& str);

  /**
   * @returns Family of the IP address.
   */
  virtual Ip_version family() const = 0;

  /**
   * @returns The binary representation (network byte ordering) of the IP address.
   */
  virtual const void* binary() const = 0;

  /**
   * @returns The result of conversion of this IP address to string.
   */
  virtual std::string to_string() const = 0;
};

/**
 * @brief Represents an abstraction of the communication endpoint identifier.
 *
 * The objects of this class can identify: Windows Named Pipes (WNP),
 * Unix Domain Sockets (UDS) and network services with address and port.
 */
class Endpoint_id {
public:
  /**
   * @brief The destructor.
   */
  virtual ~Endpoint_id() = default;

  /**
   * @returns The copy of this instance.
   */
  virtual std::unique_ptr<Endpoint_id> to_endpoint_id() const = 0;

  /**
   * @returns The communication mode of this endpoint.
   */
  virtual Communication_mode communication_mode() const = 0;

  /**
   * @returns The pipe name of the WNP if the communication mode
   * is `Communication_mode::wnp`, or `std::nullopt` otherwise.
   */
  virtual const std::optional<std::string>& wnp_pipe_name() const = 0;

  /**
   * @returns The server name of the WNP if the communication mode
   * is `Communication_mode::wnp`, or `std::nullopt` otherwise.
   */
  virtual const std::optional<std::string>& wnp_server_name() const = 0;

  /**
   * @returns The path to the UDS if the communication mode
   * is `Communication_mode::uds`, or `std::nullopt` otherwise.
   */
  virtual const std::optional<std::filesystem::path>& uds_path() const = 0;

  /**
   * @returns The network address of the host if the communication mode
   * is `Communication_mode::net`, or `std::nullopt` otherwise.
   */
  virtual const std::optional<std::string>& net_address() const = 0;

  /**
   * @returns The port number of the host if the communication mode
   * is `Communication_mode::net`, or `std::nullopt` otherwise.
   */
  virtual std::optional<int> net_port() const = 0;

private:
  friend iEndpoint_id;

  Endpoint_id() = default;
};

/**
 * @brief Represents an abstraction of Listener options.
 */
class Listener_options {
public:
  /**
   * @brief The destructor.
   */
  virtual ~Listener_options() = default;

  /// @name Constructors
  /// @{

#ifdef _WIN32
  /**
   * @returns The new instance of the options for listeners of
   * Windows Named Pipes (WNP).
   *
   * @param pipe_name - the pipe name.
   *
   * @par Effects
   * `(endpoint_id()->communication_mode() == Communication_mode::wnp)`.
   */
  static DMITIGR_COMMON_API std::unique_ptr<Listener_options> make(std::string pipe_name);
#else
  /**
   * @returns The new instance of the options for listeners of
   * Unix Domain Sockets (UDS).
   *
   * @param path - path to the UDS.
   * @param backlog - the maximum size of the queue of pending connections.
   *
   * @par Requires
   * `(backlog > 0)`
   *
   * @par Effects
   * `(endpoint_id()->communication_mode() == Communication_mode::uds)`.
   */
  static DMITIGR_COMMON_API std::unique_ptr<Listener_options> make(std::filesystem::path path, int backlog);
#endif
  /**
   * @overload
   *
   * @returns The new instance of the options for listeners of network protocols.
   *
   * @param address - the address to use for binding on.
   * @param port - the port number to use for binding on.
   * @param backlog - the maximum size of the queue of pending connections.
   *
   * @par Requires
   * `(port > 0 && backlog > 0)`
   *
   * @par Effects
   * `(endpoint_id()->communication_mode() == Communication_mode::net)`.
   */
  static DMITIGR_COMMON_API std::unique_ptr<Listener_options> make(std::string address, int port, int backlog);

  /**
   * @returns The copy of this instance.
   */
  virtual std::unique_ptr<Listener_options> to_listener_options() const = 0;

  /// @}

  /// @name Methods
  /// @{

  /**
   * @returns The endpoint identifier.
   */
  virtual const Endpoint_id* endpoint_id() const = 0;

  /**
   * @returns The value of backlog if the communication mode of the endpoint is
   * not `Communication_mode::wnp`, or `std::nullopt` otherwise.
   */
  virtual std::optional<int> backlog() const = 0;

  /// @}

private:
  friend iListener_options;

  Listener_options() = default;
};

/**
 * @brief Represents an abstraction of a network listener.
 */
class Listener {
public:
  /**
   * @brief The destructor.
   */
  virtual ~Listener() = default;

  /**
   * @returns A new instance of the network listener.
   */
  static DMITIGR_COMMON_API std::unique_ptr<Listener> make(const Listener_options* options);

  /**
   * @returns The options of the listener.
   */
  virtual const Listener_options* options() const = 0;

  /**
   * @returns `true` if the listener is listening for new client connections, or
   * `false` otherwise.
   */
  virtual bool is_listening() const = 0;

  /**
   * @brief Starts listening.
   *
   * @par Requires
   * `!is_listening()`.
   */
  virtual void listen() = 0;

  /**
   * @brief Waits for the next client connection to accept.
   *
   * @param timeout - maximum amount of time to wait before return. A special
   * value of -1 denotes "eternity".
   *
   * @returns `true` if the connection is available to accept before the
   * `timeout` elapses, or `false` otherwise.
   *
   * @par Requires
   * `is_listening()`
   *
   * @see accept().
   */
  virtual bool wait(std::chrono::milliseconds timeout = std::chrono::milliseconds{-1}) = 0;

  /**
   * @brief Accepts a new client connection.
   *
   * @returns An instance of io::Descriptor.
   *
   * @par Requires
   * `is_listening()`
   *
   * @see wait().
   */
  virtual std::unique_ptr<io::Descriptor> accept() = 0;

  /**
   * @brief Stops listening.
   */
  virtual void close() = 0;

private:
  friend iListener;

  Listener() = default;
};

// =============================================================================

/** Shutdown receive operations. */
constexpr int sd_recv = 0;

/** Shutdown send operations. */
constexpr int sd_send = 1;

/** Shutdown both send and receive operations. */
constexpr int sd_both = 2;

/**
 * @returns `true` if the `hostname` denotes a valid hostname, or
 * `false` otherwise.
 */
DMITIGR_COMMON_API bool is_hostname_valid(const std::string& hostname);

/**
 * @returns The value that denotes an invalid socket.
 */
DMITIGR_COMMON_API Socket_native invalid_socket();

/**
 * @returns `true` if the `socket` is valid or `false` otherwise.
 */
DMITIGR_COMMON_API bool is_socket_valid(Socket_native socket);

/**
 * @returns `true` if the `function_result` is represents an indication
 * of the socket API function failure or `false` otherwise.
 */
DMITIGR_COMMON_API bool is_socket_error(int function_result);

/**
 * @brief Performs polling of the `socket`.
 *
 * @returns The readiness of the socket according to the specified `mask`.
 *
 * @par Requires
 * `(socket >= 0)`
 *
 * @par Remarks
 * `(timeout < 0)` means *no timeout* and the function can block indefinitely!
 */
DMITIGR_COMMON_API Socket_readiness poll(Socket_native socket, Socket_readiness mask, std::chrono::milliseconds timeout);

} // namespace dmitigr::net

namespace dmitigr {

template<> struct Is_bitmask_enum<net::Socket_readiness> : std::true_type {};

} // namespace dmitigr

#ifdef DMITIGR_COMMON_HEADER_ONLY
#include "dmitigr/common/net.cpp"
#endif

#endif  // DMITIGR_COMMON_NET_HPP
