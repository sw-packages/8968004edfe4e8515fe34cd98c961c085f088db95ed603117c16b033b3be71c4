// -*- C++ -*-
// Copyright (C) Dmitry Igrishin
// For conditions of distribution and use, see files LICENSE.txt or dt.hpp

#ifndef DMITIGR_COMMON_DT_BASICS_HPP
#define DMITIGR_COMMON_DT_BASICS_HPP

#include "dmitigr/common/dll.hpp"

#include <string>

namespace dmitigr::dt {

/**
 * @brief Represents a day of week.
 */
enum class Day_of_week { sun, mon, tue, wed, thu, fri, sat };

/**
 * @brief Represents a month.
 */
enum class Month { jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, dec };

/**
 * @returns The result of conversion of `str` to the value of type Day_of_week.
 *
 * @remarks The value of `str` is case-sensitive.
 */
DMITIGR_COMMON_API Day_of_week to_day_of_week(std::string_view str);

/**
 * @returns The computed value of day of week.
 */
DMITIGR_COMMON_API Day_of_week day_of_week(int year, Month month, int day);

/**
 * @returns The result of conversion of `dw` to the instance of type `std::string`.
 */
DMITIGR_COMMON_API std::string to_string(Day_of_week dw);

/**
 * @returns The result of conversion of `str` to the value of type Month.
 *
 * @remarks The value of `str` is case-sensitive.
 */
DMITIGR_COMMON_API Month to_month(std::string_view str);

/**
 * @returns The result of conversion of `month` to the instance of type `std::string`.
 */
DMITIGR_COMMON_API std::string to_string(const Month month);

/**
 * @returns The day count in the specified `year` and `month`.
 */
DMITIGR_COMMON_API int day_count(int year, Month month);

} // namespace dmitigr::dt

#ifdef DMITIGR_COMMON_HEADER_ONLY
#include "dmitigr/common/dt/basics.cpp"
#endif

#endif  // DMITIGR_COMMON_DT_BASICS_HPP
