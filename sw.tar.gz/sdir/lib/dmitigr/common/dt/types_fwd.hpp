// -*- C++ -*-
// Copyright (C) Dmitry Igrishin
// For conditions of distribution and use, see files LICENSE.txt or dt.hpp

#ifndef DMITIGR_DT_TYPES_FWD_HPP
#define DMITIGR_DT_TYPES_FWD_HPP

/**
 * @brief Public API.
 *
 * @warning The nested namespaces `detail` contains implementation details
 * which should not be used in the client code.
 */
namespace dmitigr::dt {

enum class Day_of_week;
enum class Month;

class Timestamp;
class iTimestamp;

} // namespace dmitigr::dt

#endif  // DMITIGR_DT_TYPES_FWD_HPP
