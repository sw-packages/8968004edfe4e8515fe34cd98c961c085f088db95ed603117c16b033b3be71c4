The C++ library to work with date and time {#mainpage}
======================================================

The implementation is aimed to be as simple as possible (maybe even "dumb") for
better understanding and correctness.

**ATTENTION, this software is "alpha" quality, use at your own risk!**

Any [feedback][dmitigr_mailbox] (*especially results of testing*) is highly appreciated!

Features
========

Easy to use. Parsing of HTTP-date defined in [RFC7231][rfc7231_7111].

Example
=======

```cpp
#include <cassert>
#include <dmitigr/common/dt.hpp>

int main()
{
  namespace dt = dmitigr::dt;
  auto ts = dt::Timestamp::make();
  ts->set_date(2019, dt::Month::feb, 20);
  assert(ts->day_of_week() == dt::Day_of_week::wed);
}
```

Copyright
=========

Copyright (C) Dmitry Igrishin

[dmitigr_mailbox]: mailto:dmitigr@gmail.com

[rfc7231_7111]: https://tools.ietf.org/html/rfc7231#section-7.1.1.1
