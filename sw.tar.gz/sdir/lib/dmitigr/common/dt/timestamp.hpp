// -*- C++ -*-
// Copyright (C) Dmitry Igrishin
// For conditions of distribution and use, see files LICENSE.txt or dt.hpp

#ifndef DMITIGR_COMMON_TIMESTAMP_HPP
#define DMITIGR_COMMON_TIMESTAMP_HPP

#include "dmitigr/common/dll.hpp"
#include "dmitigr/common/dt/basics.hpp"
#include "dmitigr/common/dt/types_fwd.hpp"

#include <memory>

namespace dmitigr::dt {

/**
 * @brief Defines an abstraction of a timestamp.
 */
class Timestamp {
public:
  /**
   * @brief The destructor.
   */
  virtual ~Timestamp() = default;

  /// @name Constructors
  /// @{

  /**
   * @brief Constructs the timestamp that represents "1583/01/01 00:00:00".
   */
  static DMITIGR_COMMON_API std::unique_ptr<Timestamp> make();

  /**
   * @brief Constructs the object by parsing the `input`.
   *
   * Examples of valid input are:
   *
   *   1. Wed, 06 Apr 1983 17:00:00 GMT
   *
   * @param input - http-date.
   */
  static DMITIGR_COMMON_API std::unique_ptr<Timestamp> from_rfc7231(std::string_view input);

  /**
   * @returns The copy of this instance.
   */
  virtual std::unique_ptr<Timestamp> to_timestamp() const = 0;

  /// @}

  /**
   * @returns The year.
   */
  virtual int year() const = 0;

  /**
   * @returns The month.
   */
  virtual Month month() const = 0;

  /**
   * @returns The day.
   */
  virtual int day() const = 0;

  /**
   * @returns The day of week.
   */
  virtual Day_of_week day_of_week() const = 0;

  /**
   * @brief Sets the date.
   *
   * @par Exception safety guarantee
   * Strong.
   *
   * @par Requires
   * `(1 <= day && 1583 <= year && day <= day_count(year, month))`
   */
  virtual void set_date(int year, Month month, int day) = 0;

  /**
   * @returns The hour.
   */
  virtual int hour() const = 0;

  /**
   * @brief Sets the hour.
   *
   * @par Exception safety guarantee
   * Strong.
   *
   * @par Requires
   * `(0 <= hour && hour <= 59)`
   */
  virtual void set_hour(int hour) = 0;

  /**
   * @returns The minute.
   */
  virtual int minute() const = 0;

  /**
   * @brief Sets the minute.
   *
   * @par Exception safety guarantee
   * Strong.
   *
   * @par Requires
   * `(0 <= minute && minute <= 59)`
   */
  virtual void set_minute(int minute) = 0;

  /**
   * @returns The second.
   */
  virtual int second() const = 0;

  /**
   * @brief Sets the second.
   *
   * @par Exception safety guarantee
   * Strong.
   *
   * @par Requires
   * `(0 <= second && second <= 59)`
   */
  virtual void set_second(int second) = 0;

  /**
   * @brief Sets the time.
   *
   * @par Exception safety guarantee
   * Strong.
   *
   * @par Requires
   * `(0 <= hour && hour <= 59) && (0 <= minute && minute <= 59) && (0 <= second && second <= 59)`
   */
  virtual void set_time(int hour, int minute, int second) = 0;

  /// @name Conversions
  /// @{

  /**
   * @returns The result of conversion of this instance to the instance of type
   * `std::string` according to RFC7231.
   */
  virtual std::string to_rfc7231() const = 0;

  /// @}

  /// @name Utilities
  /// @{

  /**
   * @returns `true` if this instance is less than `rhs`, or `false` otherwise.
   */
  virtual bool is_less(const Timestamp* rhs) const = 0;

  /**
   * @returns `true` if this instance is equal to `rhs`, or `false` otherwise.
   */
  virtual bool is_equal(const Timestamp* rhs) const = 0;

  /// @}
private:
  friend iTimestamp;

  Timestamp() = default;
};

} // namespace dmitigr::dt

#ifdef DMITIGR_COMMON_HEADER_ONLY
#include "dmitigr/common/dt/timestamp.cpp"
#endif

#endif  // DMITIGR_COMMON_TIMESTAMP_HPP
