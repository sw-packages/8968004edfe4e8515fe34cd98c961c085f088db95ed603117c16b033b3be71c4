// -*- C++ -*-
// Copyright (C) Dmitry Igrishin
// For conditions of distribution and use, see files LICENSE.txt or common.hpp

#ifndef DMITIGR_COMMON_INLINE
  #if defined(DMITIGR_COMMON_HEADER_ONLY) && !defined(DMITIGR_COMMON_BUILDING)
    #define DMITIGR_COMMON_INLINE inline
  #else
    #define DMITIGR_COMMON_INLINE
  #endif
#endif  // DMITIGR_COMMON_INLINE

#ifndef DMITIGR_COMMON_NOMINMAX
  #ifdef _WIN32
    #ifndef NOMINMAX
      #define NOMINMAX
      #define DMITIGR_COMMON_NOMINMAX
    #endif
  #endif
#endif  // DMITIGR_COMMON_NOMINMAX
