// -*- C++ -*-
// Copyright (C) 2019 Dmitry Igrishin
//
// This software is provided 'as-is', without any express or implied
// warranty. In no event will the authors be held liable for any damages
// arising from the use of this software.
//
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it
// freely, subject to the following restrictions:
//
// 1. The origin of this software must not be misrepresented; you must not
//    claim that you wrote the original software. If you use this software
//    in a product, an acknowledgment in the product documentation would be
//    appreciated but is not required.
// 2. Altered source versions must be plainly marked as such, and must not be
//    misrepresented as being the original software.
// 3. This notice may not be removed or altered from any source distribution.
//
// Dmitry Igrishin
// dmitigr@gmail.com

#ifndef DMITIGR_COMMON_HPP
#define DMITIGR_COMMON_HPP

#include "dmitigr/common/algorithm.hpp"
#include "dmitigr/common/basics.hpp"
#include "dmitigr/common/config.hpp"
#include "dmitigr/common/console.hpp"
#include "dmitigr/common/debug.hpp"
#include "dmitigr/common/dt/basics.hpp"
#include "dmitigr/common/dt/timestamp.hpp"
#include "dmitigr/common/exceptions.hpp"
#include "dmitigr/common/filesystem_experimental.hpp"
#include "dmitigr/common/filesystem.hpp"
#include "dmitigr/common/io.hpp"
#ifdef DMITIGR_COMMON_GRAPHICSMAGICK
#include "dmitigr/common/graphicsmagick.hpp"
#endif
#include "dmitigr/common/macros.hpp"
#include "dmitigr/common/math.hpp"
#include "dmitigr/common/memory.hpp"
#include "dmitigr/common/net.hpp"
#include "dmitigr/common/os.hpp"
#include "dmitigr/common/stream.hpp"
#include "dmitigr/common/string.hpp"

#endif  // DMITIGR_COMMON_HPP
